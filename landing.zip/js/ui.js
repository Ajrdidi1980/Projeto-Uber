// ===== TROCAR TELA =====
function trocarTela(id, el) {
  // esconder telas
  document.querySelectorAll(".tela").forEach((t) => (t.style.display = "none"));

  // mostrar tela selecionada
  document.getElementById(id).style.display = "block";

  // remover ativo
  document
    .querySelectorAll(".sidebar button")
    .forEach((b) => b.classList.remove("ativo"));

  // adiciona ativo
  document.getElementById("btn-" + id).classList.add("ativo");

  if (el) {
    el.classList.add("ativo");
  }
  // atualizar resumo
  if (id === "resumo") {
    atualizar();

    setTimeout(() => {
      atualizar();

      window.dispatchEvent(new Event("resize"));
    }, 150);
  }
}
window.trocarTela = trocarTela;
